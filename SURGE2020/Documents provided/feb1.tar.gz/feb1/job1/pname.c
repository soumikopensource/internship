#include <stdio.h>
#include "mpi.h"

int main(int argc, char *argv[])
{
  int size, rank, len;
  char hostname[MPI_MAX_PROCESSOR_NAME];

  // initialize MPI
  MPI_Init(&argc,&argv);

  // get number of tasks
  MPI_Comm_size(MPI_COMM_WORLD, &size);

  // get my rank
  MPI_Comm_rank(MPI_COMM_WORLD, &rank);

  // get name of processor
  MPI_Get_processor_name(hostname, &len);
  printf ("I am %d of %d, running on %s\n", rank, size, hostname);

  // cleanup 
  MPI_Finalize();
}

