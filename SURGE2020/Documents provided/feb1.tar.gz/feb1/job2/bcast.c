#include <stdio.h>
#include "mpi.h"

#define BUFFER 1048576
//#define BUFFER 33554432 

int main(int argc, char *argv[])
{
  int size, rank, len;
  char hostname[MPI_MAX_PROCESSOR_NAME];

  double data[BUFFER];

  // initialize MPI
  MPI_Init(&argc,&argv);

  // get number of tasks
  MPI_Comm_size(MPI_COMM_WORLD, &size);

  // get my rank
  MPI_Comm_rank(MPI_COMM_WORLD, &rank);

  double tstart = MPI_Wtime();
  MPI_Bcast (data, BUFFER, MPI_DOUBLE, 0, MPI_COMM_WORLD);
  double tend = MPI_Wtime();

  printf ("%d: Bcast time %lf\n", rank, tend-tstart);

  // cleanup 
  MPI_Finalize();
}

